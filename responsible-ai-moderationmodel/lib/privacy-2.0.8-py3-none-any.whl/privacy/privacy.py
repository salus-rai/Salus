
# from privacy.service.service import PrivacyService as ps
# from privacy.service.__init__ import *
from privacy.service.textPrivacy import TextPrivacy
from privacy.service.loadRecognizer import LoadRecognizer
from privacy.config.logger import request_id_var
import uuid
class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__
class Privacy:
    def textAnalyze(payload):
        id = uuid.uuid4().hex
        request_id_var.set(id)
        return TextPrivacy.analyze(AttributeDict(payload))
        
    def textAnonymize(payload):
        id = uuid.uuid4().hex
        request_id_var.set(id)
        return TextPrivacy.anonymize(AttributeDict(payload))
    
    def loadRecogs(payload):
        id = uuid.uuid4().hex
        request_id_var.set(id)
        return LoadRecognizer.set_recognizer(AttributeDict(payload))
    
    # def imageAnalyze(payload):
    #     id = uuid.uuid4().hex
    #     request_id_var.set(id)
    #     return ps.image_analyze(AttributeDict(payload))
    # def imageAnonymize(payload):
    #     id = uuid.uuid4().hex
    #     request_id_var.set(id)
    #     return ps.image_anonymize(AttributeDict(payload))
    # def imageVerify(payload):
    #     id = uuid.uuid4().hex
    #     request_id_var.set(id)
    #     return ps.image_verify(AttributeDict(payload))
    # def imageEncrypt(payload):
    #     id = uuid.uuid4().hex
    #     request_id_var.set(id)
    #     return ps.imageEncryption(AttributeDict(payload))
    


# d=AttributeDict({
#   "inputText": "Karan is working in Infosys. He is from Mumbai. His appointment for renewing passport is booked on March 12 and his old Passport Number is P2096457. Also, he want to link his Aadhaar Number is 567845678987 with his Pan Number is BNZAA2318A.",
#   "portfolio": None,
#   "account": None,
#   "exclusionList": None
# })
# Privacy.textAnalyze(d)





