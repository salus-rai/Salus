
import os
import pymongo

from dotenv import load_dotenv
from privacy.config.logger import CustomLogger
import sys
load_dotenv()

log = CustomLogger()


class DB:
    def connect():
        try:
            myclient = pymongo.MongoClient(os.getenv("MONGO_PATH")) 
            mydb = myclient[os.getenv("PRIVACY_DB_NAME")]
            return mydb
        except Exception as e:
            log.info(str(e))
            sys.exit()
            